'use strict';

/**
Complete the function getFirstCharacter such that it returns
the first character of the name parameter it receives.

Tests: returns a string
returns first character

 * @param {string} name
 */
function getFirstCharacter(name) {
  
}

// Sample usage - do not modify
console.log(getFirstCharacter("Amsterdam")); // "A"
console.log(getFirstCharacter("Japan")); // "J"
